package com.example.digidoc.ui.medicines

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.digidoc.R

class MedicinesFragment : Fragment() {

    private lateinit var medicinesViewModel: MedicinesViewModel

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        medicinesViewModel =
                ViewModelProviders.of(this).get(MedicinesViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_medicines, container, false)
        val textView: TextView = root.findViewById(R.id.text_medicines)
        medicinesViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })
        return root
    }
}
