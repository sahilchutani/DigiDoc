package com.example.digidoc.ui.doctor

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DoctorViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "A Virtual Doctor with a video call with an actual doctor using google duo"
    }
    val text: LiveData<String> = _text
}