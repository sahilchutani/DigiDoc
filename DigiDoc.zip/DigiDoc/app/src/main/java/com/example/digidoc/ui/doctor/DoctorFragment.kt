package com.example.digidoc.ui.doctor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.digidoc.R

class DoctorFragment : Fragment() {

    private lateinit var doctorViewModel: DoctorViewModel

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        doctorViewModel =
                ViewModelProviders.of(this).get(DoctorViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_doctor, container, false)
        val textView: TextView = root.findViewById(R.id.text_doctor)
        doctorViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })
        return root
    }
}
